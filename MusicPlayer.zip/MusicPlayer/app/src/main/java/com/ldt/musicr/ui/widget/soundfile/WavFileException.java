package com.ldt.musicr.ui.widget.soundfile;

/**
 * Created by trung on 9/9/2017.
 */
/**
 * @author Anna Stępień <anna.stepien@semantive.com>
 */
public class WavFileException extends Exception {

    public WavFileException(final String message) {
        super(message);
    }
}